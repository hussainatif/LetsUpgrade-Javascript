var fruits = ["Banana", "Orange", "Apple", "Mango"];
for(var i=0;i<fruits.length;i++){
	if(fruits[i].includes('a')==true)
	{
		console.log(fruits[i])
	}
}
  
