var min=4;
var sec=min*60;
console.log(sec);