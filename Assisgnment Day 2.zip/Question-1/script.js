var str = "Hello world";
var n = str.indexOf("w")
console.log("'W' in the string 'Hello world' is at index " +n);
