var arr=[23,56,12,43,35];
for(var i=arr.length;i>=0;i--){
	console.log(arr[i]);
}