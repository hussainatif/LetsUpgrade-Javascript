function myFunction() { 
        	// console.log("Heloo")
         //    var x = document.getElementById("myText").value; 
         //    document.getElementById( "myText1").innerHTML = x; 


        var f1 = document.getElementById("myText");
        var f2 = document.getElementById("myText1");
        f2.value = f1.value;
    }
 