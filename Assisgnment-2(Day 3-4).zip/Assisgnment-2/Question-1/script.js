function changeImage2() {
  const element = document.getElementById("image");
  //console.log(ele.id);
  const newUrl = "VK.jpg";
	element.src = newUrl;
	//console.log("Virat");
}

function changeImage3() {
  const element = document.getElementById("image");
  //console.log(ele.id);
  const newUrl = "Rahane.jpg";
	element.src = newUrl;
	//console.log("Rahane");
}

function changeImage1() {
  const element = document.getElementById("image");
  //console.log(ele.id);
  const newUrl = "shami.jpg";
	element.src = newUrl;
	//console.log("shami");
}